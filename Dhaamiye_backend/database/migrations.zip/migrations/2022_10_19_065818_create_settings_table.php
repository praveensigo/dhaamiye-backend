<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->decimal('fuel_delivery_range', 12, 2);
            $table->decimal('commision', 12, 2);
            $table->decimal('min_fuel_level', 12, 2);
            $table->string('android_version');
            $table->string('ios_version');
            $table->integer('maintenance');
            $table->text('maintenance_reason');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }
};
